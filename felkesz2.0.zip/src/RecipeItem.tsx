import "./RecipeItem.less";

export function RecipeItem({ item, togglePurchased, deleteItem }: {
    item: { id: number, name: string, quantity: string, purchased: boolean },
    togglePurchased: (id: number) => void,
    deleteItem: (id: number) => void
}) {
    return (
        <li key={item.id}>
            <label class="item-label">
                <input
                    type="checkbox"
                    class="item-checkbox"
                    checked={item.purchased}
                    onChange={() => togglePurchased(item.id)}
                />
                <span class="item-text">{item.name} - {item.quantity}</span>
                <button class="delete-button" onClick={() => deleteItem(item.id)}>
                    <span class="material-symbols-outlined item-delete">
                        delete
                    </span>
                </button>
            </label>
        </li>
    );
}