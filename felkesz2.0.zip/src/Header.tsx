import "./Header.less";

export function Header({ recipeName, isEditing, setIsEditing }: {
    recipeName: string,
    isEditing: boolean,
    setIsEditing: (isEditing: boolean) => void
}) {
    return (
        <div class="header">
            <h3>{recipeName}</h3>
            <button 
                class="material-symbols-outlined edit-button"
                onClick={() => setIsEditing(!isEditing)}
            >
                edit
            </button>
        </div>
    );
}