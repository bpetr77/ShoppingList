import "./RightPane.less";
import { useEffect, useState } from "preact/hooks";
import { RecipePane } from "./RecipePane";
import { Recipe } from "./Recipe";

export function RightPane({ showAddRecipeForm, addRecipe, selectedRecipe, setSelectedRecipe, updateRecipe }: {
    showAddRecipeForm: boolean,
    addRecipe: (recipe: Recipe) => void,
    selectedRecipe: Recipe | null,
    setSelectedRecipe: (recipe: Recipe | null) => void
    updateRecipe: (recipe: Recipe) => void
}) {
    const [isEditing, setIsEditing] = useState(false);
    const [newItemName, setNewItemName] = useState("");
    const [newItemQuantity, setNewItemQuantity] = useState("");
    const [isDarkMode, setIsDarkMode] = useState(() => {
        // Betöltjük a sötét mód állapotát a localStorage-ból
        return localStorage.getItem('theme') === 'dark';
    });

    useEffect(() => {
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
        } else {
            document.body.classList.remove('dark-mode');
            localStorage.setItem('theme', 'light');
        }
    }, [isDarkMode]);

    const deleteItem = (itemId: number) => {
        if (selectedRecipe) {
            const updatedItems = selectedRecipe.items.filter(item => item.id !== itemId);
            const updatedRecipe = new Recipe(selectedRecipe.id, selectedRecipe.name);
            updatedRecipe.items = updatedItems;
            updatedRecipe.createdAt = selectedRecipe.createdAt;
            setSelectedRecipe(updatedRecipe);
        }
    };

    const addItemToRecipe = () => {
        if (selectedRecipe) {
            const newItem = {
                id: Date.now(),
                name: newItemName,
                quantity: newItemQuantity,
                purchased: false
            };
            const updatedItems = [...selectedRecipe.items, newItem];
            const updatedRecipe = new Recipe(selectedRecipe.id, selectedRecipe.name);
            updatedRecipe.items = updatedItems;
            updatedRecipe.createdAt = selectedRecipe.createdAt;
            setSelectedRecipe(updatedRecipe);
            setNewItemName("");
            setNewItemQuantity("");
        }
    };

    const saveChanges = () => {
        if (selectedRecipe) {
            updateRecipe(selectedRecipe); // Frissítjük a recipes állapotot a Main komponensben
        }
        setIsEditing(false); // Kilépünk a szerkesztési módból
    };

    return (
        <div class="RightPane">
            {showAddRecipeForm && !selectedRecipe && <RecipePane addRecipe={addRecipe} isDarkMode={isDarkMode}/>} {/* Csak akkor jelenik meg, ha showAddRecipeForm igaz és nincs kiválasztott recept */}
            {selectedRecipe && (
                <div class="recipe-details">
                    <div class="header">
                        <h3>{selectedRecipe.name}</h3>
                        <button
                            class="material-symbols-outlined edit-button"
                            onClick={() => setIsEditing(!isEditing)}
                        >
                            edit
                        </button>
                    </div>
                    {isEditing && (
                        <div class="edit-form">
                            <input
                                type="text"
                                placeholder="Item name"
                                value={newItemName}
                                onChange={e => setNewItemName(e.currentTarget.value)}
                            />
                            <input
                                type="text"
                                placeholder="Quantity"
                                value={newItemQuantity}
                                onChange={e => setNewItemQuantity(e.currentTarget.value)}
                            />
                            <button class="add-item-button" onClick={addItemToRecipe}>
                                <span class="material-symbols-outlined">
                                    add
                                </span>
                                Add Item
                            </button>
                        </div>
                    )}
                    {selectedRecipe.items.length > 0 ? (
                        <ul>
                            {selectedRecipe.items.map(item => (
                                <li key={item.id}>
                                    <label>
                                        <input
                                            type="checkbox"
                                            checked={item.purchased}
                                            onChange={() => {
                                                const updatedItems = selectedRecipe.items.map(i =>
                                                    i.id === item.id ? { ...i, purchased: !i.purchased } : i
                                                );
                                                const updatedRecipe = new Recipe(selectedRecipe.id, selectedRecipe.name);
                                                updatedRecipe.items = updatedItems;
                                                updatedRecipe.createdAt = selectedRecipe.createdAt;
                                                setSelectedRecipe(updatedRecipe);
                                            }}
                                            class="item-checkbox"
                                        />
                                        <span class="item-text">{item.name} - {item.quantity}</span>
                                    </label>
                                    <button class="delete-button" onClick={() => deleteItem(item.id)}>
                                        <span class="material-symbols-outlined">
                                            delete
                                        </span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p>No items in this recipe.</p>
                    )}
                    <button class="material-symbols-outlined save-button"
                        onClick={saveChanges}
                    >save</button>
                </div>
            )}
                    <button 
                        class="material-symbols-outlined mode-change-button"
                        onClick={() => setIsDarkMode(!isDarkMode)} // Állapot váltása kattintáskor
                    >
                        {isDarkMode ? "light_mode" : "dark_mode"} {/* Ikon váltása az állapot alapján */}
                    </button>
        </div>
    );
}