import "./RecipeDetails.less";
import { RecipeItem } from "./RecipeItem";

export function RecipeDetails({ selectedRecipe, deleteItem, addItemToRecipe, newItemName, setNewItemName, newItemQuantity, setNewItemQuantity, isEditing }: {
    selectedRecipe: any,
    deleteItem: (itemId: number) => void,
    addItemToRecipe: () => void,
    newItemName: string,
    setNewItemName: (name: string) => void,
    newItemQuantity: string,
    setNewItemQuantity: (quantity: string) => void,
    isEditing: boolean,
    togglePurchased: (id: number) => void
}) {
    return (
        <div class="recipe-details">
            {isEditing && (
                <div class="edit-form">
                    <input
                        type="text"
                        placeholder="Item name"
                        value={newItemName}
                        onChange={e => setNewItemName(e.currentTarget.value)}
                    />
                    <input
                        type="text"
                        placeholder="Quantity"
                        value={newItemQuantity}
                        onChange={e => setNewItemQuantity(e.currentTarget.value)}
                    />
                    <button class="add-item-button" onClick={addItemToRecipe}>
                        Add Item
                    </button>
                </div>
            )}
            {selectedRecipe.items.length > 0 ? (
                <ul>
                    {selectedRecipe.items.map(item => (
                        <RecipeItem
                        key={item.id}
                        item={item}
                        togglePurchased={togglePurchased}
                        deleteItem={deleteItem}
                        />
                    ))}
                </ul>
            ) : (
                <p>No items in this recipe.</p>
            )}
        </div>
    );
}