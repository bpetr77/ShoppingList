import { useState } from "preact/hooks";
import "./RecipeForm.less";
export function RecipeForm({ addItemToNewRecipe, newItemName, setNewItemName, newItemQuantity, setNewItemQuantity }: {
    addItemToNewRecipe: () => void,
    newItemName: string,
    setNewItemName: (name: string) => void,
    newItemQuantity: string,
    setNewItemQuantity: (quantity: string) => void
}) {
    return (
        <div class="recipe-form">
            <input
                type="text"
                placeholder="Item name"
                value={newItemName}
                onChange={e => setNewItemName(e.currentTarget.value)}
            />
            <input
                type="text"
                placeholder="Quantity"
                value={newItemQuantity}
                onChange={e => setNewItemQuantity(e.currentTarget.value)}
            />
            <button class="button" onClick={addItemToNewRecipe}>
                <span class="material-symbols-outlined">add</span>
                Add Item
            </button>
        </div>
    );
}