import { useState } from "preact/hooks";
import { Recipe, RecipeItem } from "./Recipe";
import { RecipeForm } from "./RecipeForm";
import { RecipeList } from "./RecipeList";
import './RecipePane.less';

export function RecipePane({ addRecipe, isDarkMode }: { addRecipe: (recipe: Recipe) => void, isDarkMode: boolean }) {
    const [newRecipeName, setNewRecipeName] = useState("");
    const [newItemName, setNewItemName] = useState("");
    const [newItemQuantity, setNewItemQuantity] = useState("");
    const [newRecipeItems, setNewRecipeItems] = useState<RecipeItem[]>([]);

    const handleAddRecipe = () => {
        if (newRecipeName.trim() === "") {
            return; // Ha a cím üres, ne csináljon semmit
        }
        const newRecipe = new Recipe(Date.now(), newRecipeName);
        newRecipe.items = newRecipeItems;
        addRecipe(newRecipe);
        setNewRecipeName("");
        setNewRecipeItems([]);
    };

    const addItemToNewRecipe = () => {
        const newItem: RecipeItem = {
            id: Date.now(), // Egyedi azonosító generálása
            name: newItemName,
            quantity: newItemQuantity,
            purchased: false
        };
        setNewRecipeItems([...newRecipeItems, newItem]);
        setNewItemName("");
        setNewItemQuantity("");
    };

    const togglePurchased = (itemId: number) => {
        setNewRecipeItems(newRecipeItems.map(item =>
            item.id === itemId ? { ...item, purchased: !item.purchased } : item
        ));
    };

    const deleteItem = (itemId: number) => {
        setNewRecipeItems(newRecipeItems.filter(i => i.id !== itemId));
    }

    return (
        <div class={`RecipePane ${isDarkMode ? 'dark-mode' : ''}`}>
            <h3>Add a new recipe</h3>
            <input
                type="text"
                placeholder="Recipe name"
                value={newRecipeName}
                onChange={e => setNewRecipeName(e.currentTarget.value)}
                class="recipe-name-input"
            />
            <h4>Add items:</h4>
            <RecipeForm
                addItemToNewRecipe={addItemToNewRecipe}
                newItemName={newItemName}
                setNewItemName={setNewItemName}
                newItemQuantity={newItemQuantity}
                setNewItemQuantity={setNewItemQuantity}
            />
            <RecipeList
                items={newRecipeItems}
                togglePurchased={togglePurchased}
                deleteItem={deleteItem}
            />
            <button className="button-right" onClick={handleAddRecipe}>
                <span className="material-symbols-outlined">add</span>
                Add Recipe
            </button>
        </div>
    );
}