
import "./Main.less"
import { LeftPane } from "./LeftPane";
import { RightPane } from "./RightPane";
import { useEffect, useState } from "preact/hooks";
import { Recipe } from "./Recipe";
import { addRecipeToDB, deleteRecipeFromDB, getAllRecipesFromDB, updateRecipeToDB } from "./db";

export function Main() {
    let [showAddRecipeForm, setShowAddRecipeForm] = useState(false);
    const [recipes, setRecipes] = useState<Recipe[]>([]);
    const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

    useEffect(() => {
        async function loadRecipes() {
            const storedRecipes = await getAllRecipesFromDB();
            setRecipes(storedRecipes);
        }
        loadRecipes();
    }, []);


    const addRecipe = async (recipe: Recipe) => {
        setRecipes([...recipes, recipe]);
        await addRecipeToDB(recipe);
    };

    const updateRecipe = async (updatedRecipe: Recipe) => {
        setRecipes(recipes.map(recipe => 
            recipe.id === updatedRecipe.id ? updatedRecipe : recipe
        ));
        await updateRecipeToDB(updatedRecipe);
    };
    
    const deleteRecipe = async (recipeId: number) => {
        setRecipes(recipes.filter(recipe => recipe.id !== recipeId));
        await deleteRecipeFromDB(recipeId);
    };
    return <div class="Main">
        <LeftPane
            onAddClick={() => {
                setShowAddRecipeForm(true);
                setSelectedRecipe(null); // Töröljük a kiválasztott receptet, ha új receptet akarunk hozzáadni
            }}
            recipes={recipes}
            onRecipeClick={setSelectedRecipe}
            onDeleteRecipe={deleteRecipe}
        />                    
        <RightPane
            showAddRecipeForm={showAddRecipeForm}
            addRecipe={addRecipe}
            selectedRecipe={selectedRecipe}
            setSelectedRecipe={setSelectedRecipe}
            updateRecipe={updateRecipe} // Továbbítjuk az updateRecipe függvényt
        />
    </div>

}
