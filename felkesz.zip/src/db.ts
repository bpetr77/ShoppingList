import { openDB } from 'idb';
import { Recipe } from './Recipe';

const DB_NAME = 'recipesDB';
const STORE_NAME = 'recipes';

const dbPromise = openDB(DB_NAME, 1, {
    upgrade(db) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
    },
});

export async function getAllRecipesFromDB() {
    const db = await dbPromise;
    return db.getAll(STORE_NAME);
}

export async function addRecipeToDB(recipe: Recipe) {
    const db = await dbPromise;
    return db.put(STORE_NAME, recipe);
}

export async function updateRecipeToDB(recipe: Recipe) {
    const db = await dbPromise;
    return db.put(STORE_NAME, recipe);
}

export async function deleteRecipeFromDB(id: number) {
    const db = await dbPromise;
    return db.delete(STORE_NAME, id);
}