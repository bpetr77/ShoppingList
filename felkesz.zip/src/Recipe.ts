export interface RecipeItem {
    id: number;
    name: string;
    quantity: string;
    purchased: boolean;
}

export class Recipe {
    id: number;
    name: string;
    items: RecipeItem[];
    createdAt: Date;
    

    constructor(id: number, name: string) {
        this.id = id;
        this.name = name;
        this.items = [];
        this.createdAt = new Date();
    }

    addItem(name: string, quantity: string) {
        const newItem: RecipeItem = {
            id: this.items.length + 1,
            name: name,
            quantity: quantity,
            purchased: false
        };
        this.items.push(newItem);
    }

    togglePurchased(itemId: number) {
        const item = this.items.find(item => item.id === itemId);
        if (item) {
            item.purchased = !item.purchased;
        }
    }
}