import { useState } from "preact/hooks";
import { Recipe, RecipeItem } from "./Recipe";
import "./RecipePane.less";

export function RecipePane({ addRecipe, isDarkMode}: { addRecipe: (recipe: Recipe) => void, isDarkMode: boolean }) {
    const [newRecipeName, setNewRecipeName] = useState("");
    const [newItemName, setNewItemName] = useState("");
    const [newItemQuantity, setNewItemQuantity] = useState("");
    const [newRecipeItems, setNewRecipeItems] = useState<RecipeItem[]>([]);

    const handleAddRecipe = () => {
        if (newRecipeName.trim() === "") {
            return; // Ha a cím üres, ne csináljon semmit
        }
        const newRecipe = new Recipe(Date.now() - 1, newRecipeName);
        newRecipe.items = newRecipeItems;
        addRecipe(newRecipe);
        setNewRecipeName("");
        setNewRecipeItems([]);
    };

    const addItemToNewRecipe = () => {
        const newItem: RecipeItem = {
            id: Date.now(),
            name: newItemName,
            quantity: newItemQuantity,
            purchased: false
        };
        setNewRecipeItems([...newRecipeItems, newItem]);
        setNewItemName("");
        setNewItemQuantity("");
    };

    const togglePurchased = (itemId: number) => {
        setNewRecipeItems(newRecipeItems.map(item =>
            item.id === itemId ? { ...item, purchased: !item.purchased } : item
        ));
    };

    const deleteItem = (itemId: number) => {
        setNewRecipeItems(newRecipeItems.filter(i => i.id !== itemId));
    }
    return (
        <div class={`RecipePane ${isDarkMode ? 'dark-mode' : ''}`}>
            <h3>Add a new recipe</h3>
            <div class="recipe-form">
                <input
                    type="text"
                    placeholder="Recipe name"
                    value={newRecipeName}
                    onChange={e => setNewRecipeName(e.currentTarget.value)}
                />
                <h4>Add items</h4>
                <input
                    type="text"
                    placeholder="Item name"
                    value={newItemName}
                    onChange={e => setNewItemName(e.currentTarget.value)}
                />
                <input
                    type="text"
                    placeholder="Quantity"
                    value={newItemQuantity}
                    onChange={e => setNewItemQuantity(e.currentTarget.value)}
                />
                <button class="button" onClick={addItemToNewRecipe}><span class="material-symbols-outlined">
                    add
                </span>Add Item</button>
                <ul>
                    {newRecipeItems.map(item => (
                        <li key={item.id}>
                            <label class="item-label">
                                <input
                                    type="checkbox"
                                    class="item-checkbox"
                                    checked={item.purchased}
                                    onChange={() => togglePurchased(item.id)}
                                />
                                <span class="item-text">{item.name} - {item.quantity}</span>
                                <button class="delete-button" onClick={() => deleteItem(item.id)}>
                                <span class="material-symbols-outlined item-delete">
                                    delete
                                </span>
                                </button>
                            </label>
                        </li>
                    ))}
                </ul>
            </div>
            <button class="button-right" onClick={handleAddRecipe}>
                <span class="material-symbols-outlined">
                    add
                </span>
                Add Recipe
            </button>

        </div>
    );
}