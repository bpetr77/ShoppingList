import "./LeftPane.less"
import { RecipeCard } from "./RecipeCard";
import { Recipe } from "./Recipe";
import { deleteRecipeFromDB } from "./db";

export function LeftPane({ onAddClick, recipes, onRecipeClick, onDeleteRecipe }: {
	onAddClick: () => void
	recipes: Recipe[]
	onRecipeClick: (recipe: Recipe) => void
    onDeleteRecipe: (recipeId: number) => void
}) {
	return <div class="LeftPane">
		<div>
			<h3>Recipes</h3>
			{recipes.length > 0 ? (
                <div className="recipes">
                    {recipes.map(recipe => (
                        <RecipeCard
                            key={recipe.id}
                            recipe={recipe}
                            selected={false} // Itt beállíthatod a kiválasztott állapotot, ha szükséges
                            onSelect={() => onRecipeClick(recipe)} // Itt kezelheted a kiválasztási logikát, ha szükséges
                            onDelete={() => onDeleteRecipe(recipe.id)} // Itt kezelheted a törlési logikát, ha szükséges
                        />
                    ))}
                </div>
            ) : (
                <p>No recipes available. Please add a recipe.</p>
            )}
		</div>
		<button class="material-symbols-outlined add-button" onClick={onAddClick}>
			add
		</button>
	</div>
}

